import os
import random
import sqlite3
from datetime import datetime
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json

from flask import (
    Flask,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash


AUTHOR_NAME = os.environ.get("AUTHOR_NAME", "Искандер")

QUESTIONS = [
    {
        "id": 1,
        "question": "Что чаще всего используют в Python, чтобы обучить модель машинного обучения?",
        "options": ["random", "scikit-learn", "turtle", "calendar"],
        "answer": "scikit-learn",
        "explanation": "scikit-learn содержит готовые алгоритмы и инструменты для обучения моделей.",
    },
    {
        "id": 2,
        "question": "Как называется процесс, когда модель учится на примерах?",
        "options": ["Обучение", "Архивация", "Компиляция", "Сортировка"],
        "answer": "Обучение",
        "explanation": "Во время обучения модель ищет закономерности в данных.",
    },
    {
        "id": 3,
        "question": "Что такое датасет?",
        "options": [
            "Набор данных для анализа или обучения",
            "Команда для запуска сервера",
            "Тип HTML-страницы",
            "Пароль администратора",
        ],
        "answer": "Набор данных для анализа или обучения",
        "explanation": "Датасет состоит из данных, на которых можно обучать или проверять модель.",
    },
    {
        "id": 4,
        "question": "Какая библиотека Python часто используется для нейронных сетей?",
        "options": ["Flask", "TensorFlow", "SQLite", "Jinja"],
        "answer": "TensorFlow",
        "explanation": "TensorFlow помогает создавать и обучать нейронные сети.",
    },
    {
        "id": 5,
        "question": "Зачем модель делят на обучающую и тестовую выборки?",
        "options": [
            "Чтобы проверить модель на данных, которых она не видела",
            "Чтобы удалить все ошибки Python",
            "Чтобы сделать сайт красивее",
            "Чтобы отключить базу данных",
        ],
        "answer": "Чтобы проверить модель на данных, которых она не видела",
        "explanation": "Тестовая выборка помогает понять, как модель работает на новых данных.",
    },
    {
        "id": 6,
        "question": "Что означает API в проекте с Flask?",
        "options": [
            "Способ обмена данными между программами",
            "Стиль оформления кнопок",
            "Формат пароля",
            "Название базы данных",
        ],
        "answer": "Способ обмена данными между программами",
        "explanation": "Через API сайт может получать данные от внешних сервисов, например погоду.",
    },
    {
        "id": 7,
        "question": "Какой формат данных часто возвращает веб-API?",
        "options": ["JSON", "PNG", "MP3", "ZIP"],
        "answer": "JSON",
        "explanation": "JSON удобен для передачи структурированных данных между сервисами.",
    },
    {
        "id": 8,
        "question": "Что лучше сделать с паролем перед сохранением в базу данных?",
        "options": [
            "Сохранить хеш пароля",
            "Записать его в открытом виде",
            "Отправить всем пользователям",
            "Положить в CSS-файл",
        ],
        "answer": "Сохранить хеш пароля",
        "explanation": "Хеширование защищает пароль, даже если кто-то получит доступ к базе.",
    },
]

DAY_NAMES_RU = {
    0: "Понедельник",
    1: "Вторник",
    2: "Среда",
    3: "Четверг",
    4: "Пятница",
    5: "Суббота",
    6: "Воскресенье",
}


app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret-key-change-me"),
    DATABASE=os.path.join(app.instance_path, "quiz.sqlite"),
)

os.makedirs(app.instance_path, exist_ok=True)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(app.config["DATABASE"])
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            display_name TEXT NOT NULL UNIQUE,
            score INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.commit()
    db.close()


init_db()


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None

    return get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "author_name": AUTHOR_NAME}


def fetch_json(url, timeout=8):
    req = Request(url, headers={"User-Agent": "python-flask-ai-quiz/1.0"})
    with urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def get_weather(city):
    city = city.strip()
    if not city:
        return None, "Введите название города."

    geo_params = urlencode(
        {
            "name": city,
            "count": 1,
            "language": "ru",
            "format": "json",
        }
    )
    geo_url = f"https://geocoding-api.open-meteo.com/v1/search?{geo_params}"

    try:
        geo_data = fetch_json(geo_url)
        results = geo_data.get("results", [])
        if not results:
            return None, "Город не найден. Проверьте название и попробуйте снова."

        place = results[0]
        forecast_params = urlencode(
            {
                "latitude": place["latitude"],
                "longitude": place["longitude"],
                "daily": "temperature_2m_max,temperature_2m_min",
                "timezone": "auto",
                "forecast_days": 3,
            }
        )
        forecast_url = f"https://api.open-meteo.com/v1/forecast?{forecast_params}"
        forecast_data = fetch_json(forecast_url)
    except Exception:
        return None, "Не получилось получить прогноз. Попробуйте позже."

    daily = forecast_data.get("daily", {})
    dates = daily.get("time", [])
    day_temps = daily.get("temperature_2m_max", [])
    night_temps = daily.get("temperature_2m_min", [])

    rows = []
    for date_text, day_temp, night_temp in zip(dates, day_temps, night_temps):
        date_obj = datetime.strptime(date_text, "%Y-%m-%d")
        rows.append(
            {
                "weekday": DAY_NAMES_RU[date_obj.weekday()],
                "date": date_obj.strftime("%d.%m.%Y"),
                "day_temp": round(day_temp),
                "night_temp": round(night_temp),
            }
        )

    place_name = place.get("name", city)
    country = place.get("country", "")
    title = f"{place_name}, {country}" if country else place_name
    return {"city": title, "rows": rows}, None


def login_required():
    if not session.get("user_id"):
        flash("Сначала войдите в систему.", "warning")
        return redirect(url_for("login"))
    return None


def get_question(question_id):
    return next((q for q in QUESTIONS if q["id"] == question_id), None)


@app.route("/", methods=["GET", "POST"])
def index():
    city = request.form.get("city", "Москва") if request.method == "POST" else "Москва"
    weather, weather_error = get_weather(city)
    return render_template("index.html", city=city, weather=weather, weather_error=weather_error)


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("quiz"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")
        display_name = request.form.get("display_name", "").strip()

        if not username or not password or not password_confirm or not display_name:
            flash("Заполните все поля.", "danger")
        elif len(username) < 3:
            flash("Логин должен быть не короче 3 символов.", "danger")
        elif len(password) < 6:
            flash("Пароль должен быть не короче 6 символов.", "danger")
        elif password != password_confirm:
            flash("Пароли не совпадают.", "danger")
        else:
            try:
                db = get_db()
                db.execute(
                    "INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)",
                    (
                        username,
                        generate_password_hash(password, method="pbkdf2:sha256"),
                        display_name,
                    ),
                )
                db.commit()
                flash("Регистрация прошла успешно. Теперь можно войти.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                existing = get_db().execute(
                    "SELECT username, display_name FROM users WHERE username = ? OR display_name = ?",
                    (username, display_name),
                ).fetchone()
                if existing and existing["username"] == username:
                    flash("Такой логин уже занят.", "danger")
                else:
                    flash("Такое показываемое имя уже занято.", "danger")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("quiz"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Неверный логин или пароль.", "danger")
        else:
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Добро пожаловать, {user['display_name']}!", "success")
            return redirect(url_for("quiz"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("index"))


@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    redirect_response = login_required()
    if redirect_response:
        return redirect_response

    user = current_user()

    if request.method == "POST":
        question = get_question(session.pop("question_id", None))
        selected = request.form.get("answer")

        if question is None:
            flash("Вопрос устарел. Показываю новый.", "warning")
        elif selected == question["answer"]:
            get_db().execute("UPDATE users SET score = score + 1 WHERE id = ?", (user["id"],))
            get_db().commit()
            result = {
                "status": "correct",
                "message": "Верно! +1 к общему счету.",
                "explanation": question["explanation"],
            }
            session["last_result"] = result
        else:
            result = {
                "status": "wrong",
                "message": f"Почти! Правильный ответ: {question['answer']}.",
                "explanation": question["explanation"],
            }
            session["last_result"] = result
        return redirect(url_for("quiz"))

    result = session.pop("last_result", None)
    question = random.choice(QUESTIONS)
    shuffled_options = question["options"][:]
    random.shuffle(shuffled_options)
    session["question_id"] = question["id"]
    user = current_user()

    return render_template(
        "quiz.html",
        user=user,
        question=question,
        options=shuffled_options,
        result=result,
    )


@app.route("/leaderboard")
def leaderboard():
    leaders = get_db().execute(
        "SELECT display_name, score FROM users ORDER BY score DESC, display_name ASC LIMIT 20"
    ).fetchall()
    return render_template("leaderboard.html", leaders=leaders)


if __name__ == "__main__":
    app.run(debug=True)
