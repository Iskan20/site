# Flask AI Quiz

Динамический сайт-викторина для подростков на тему разработки ИИ на Python.

## Что есть в проекте

- Flask-приложение с навигационным меню.
- Регистрация и вход в систему.
- SQLite-база данных с пользователями и общим счетом.
- Бесконечная викторина: вопросы задаются случайно, счет сохраняется в аккаунте.
- Таблица лидеров.
- Главная страница с прогнозом погоды на 3 дня через Open-Meteo API.
- Footer с именем разработчика.

Open-Meteo выбран потому, что `api.open-meteo.com` и `geocoding-api.open-meteo.com` есть в allowlist для бесплатных аккаунтов PythonAnywhere:

```text
https://www.pythonanywhere.com/whitelist/
```

Имя разработчика можно изменить через переменную окружения `AUTHOR_NAME` или прямо в `app.py`.

## Локальный запуск

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
flask --app app run
```

После запуска сайт будет доступен по адресу:

```text
http://127.0.0.1:5000
```

## Размещение на PythonAnywhere

1. Зарегистрируйтесь или войдите на https://www.pythonanywhere.com.
2. Откройте вкладку **Files** и загрузите файлы проекта в папку, например:

```text
/home/your_username/flask_ai_quiz
```

3. Откройте вкладку **Consoles**, создайте Bash-консоль и выполните:

```bash
cd /home/your_username/flask_ai_quiz
python3.10 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

4. Откройте вкладку **Web**, нажмите **Add a new web app**.
5. Выберите **Manual configuration** и Python 3.10 или новее.
6. В разделе **Virtualenv** укажите путь:

```text
/home/your_username/flask_ai_quiz/.venv
```

7. В разделе **Code** откройте WSGI-файл и замените его содержимое на:

```python
import sys

project_home = "/home/your_username/flask_ai_quiz"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application
```

8. Замените `your_username` на ваш логин PythonAnywhere.
9. Нажмите **Reload** во вкладке **Web**.

После этого сайт будет доступен по адресу:

```text
https://your_username.pythonanywhere.com
```
